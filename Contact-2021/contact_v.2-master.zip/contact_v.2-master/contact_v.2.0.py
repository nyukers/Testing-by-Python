from tkinter import *

win_root = Tk()
win_root.title('Контакты')
win_root.iconbitmap('logotip.ico')
win_root.geometry('850x400+500+150')
