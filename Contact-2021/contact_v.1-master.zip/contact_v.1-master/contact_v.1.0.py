last_name = input('Введите фамилию: ')
first_name = input('Введите имя: ')
address = input('Введите адрес: ')
phone_number = input('Введите телефонный номер: ')

