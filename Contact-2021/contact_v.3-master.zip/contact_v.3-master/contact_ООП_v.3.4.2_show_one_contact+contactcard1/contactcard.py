
class ContactCard:
    '''Формирует окно "Контакт".'''
    def __init__(self, data_str):
        print(data_str)
            
if __name__ == '__main__':
    ContactCard('Проверка: Сидоров') 
